import { vec } from '../utils/vectorMath';

// ─── Gap decomposition ───
function decomposeGap(gapVec, threshold) {
  const result = [];
  if (Math.abs(gapVec.x) > threshold) result.push({ axis: "X", delta: gapVec.x });
  if (Math.abs(gapVec.y) > threshold) result.push({ axis: "Y", delta: gapVec.y });
  if (Math.abs(gapVec.z) > threshold) result.push({ axis: "Z", delta: gapVec.z });
  return result;
}

function directionLabel(axis, dir) {
  const map = { X: ["+X(East)", "-X(West)"], Y: ["+Y(North)", "-Y(South)"], Z: ["+Z(Up)", "-Z(Down)"] };
  return axis ? (dir > 0 ? map[axis][0] : map[axis][1]) : "unknown";
}

function formatGapAxes(axes) {
  return axes.map(a => `${a.axis}=${a.delta.toFixed(1)}mm`).join(", ");
}

function buildInsertDescription(gapAmt, direction, context, upstream) {
  return `INSERT [R-GAP-02]: Fill ${gapAmt.toFixed(1)}mm gap along ${direction}\n  Inherited from Row ${upstream._rowIndex}`;
}

function buildTrimDescription(overlapAmt, direction, current, next, target) {
  const trimRow = target === "current" ? current : next;
  const otherRow = target === "current" ? next : current;
  return `TRIM [${target === "current" ? "R-OVR-01" : "R-OVR-02"}]: ` +
    `Reduce ${trimRow.type} by ${overlapAmt.toFixed(1)}mm along ${direction}\n` +
    `  Row ${trimRow._rowIndex}: ${target === "current" ? "EP2" : "EP1"} adjusted\n` +
    `  Overlap with ${otherRow.type} (Row ${otherRow._rowIndex}) resolved`;
}

function analyzeOverlap(overlapAmt, context, current, next, cfg) {
  const autoTrimMax = cfg.autoTrimMaxOverlap ?? 25.0;
  const currType = (current.type || "").toUpperCase();
  const nextType = (next.type || "").toUpperCase();
  const dir = directionLabel(context.travelAxis, context.travelDirection);

  // R-OVR-03: Rigid-on-rigid
  if (currType !== "PIPE" && nextType !== "PIPE") {
    return {
      type: "ERROR", ruleId: "R-OVR-03", tier: 4,
      description: `ERROR [R-OVR-03]: ${currType} overlaps ${nextType} by ${overlapAmt.toFixed(1)}mm. Both are rigid fittings. Cannot auto-trim.`,
      current, next
    };
  }

  // R-OVR-01: Current is PIPE — trim it
  if (currType === "PIPE" && overlapAmt <= autoTrimMax) {
    return {
      type: "TRIM", ruleId: "R-OVR-01", tier: 2,
      description: buildTrimDescription(overlapAmt, dir, current, next, "current"),
      trimAmount: overlapAmt, trimTarget: "current",
      current, next
    };
  }

  // R-OVR-02: Current is rigid, next is PIPE — trim next
  if (currType !== "PIPE" && nextType === "PIPE" && overlapAmt <= autoTrimMax) {
    return {
      type: "TRIM", ruleId: "R-OVR-02", tier: 2,
      description: buildTrimDescription(overlapAmt, dir, current, next, "next"),
      trimAmount: overlapAmt, trimTarget: "next",
      current, next
    };
  }

  // Large overlap
  return {
    type: "REVIEW", ruleId: "R-OVR-01", tier: 3,
    description: `REVIEW [R-OVR-01]: ${overlapAmt.toFixed(1)}mm overlap between ${currType} (Row ${current._rowIndex}) and ${nextType} (Row ${next._rowIndex}). Exceeds ${autoTrimMax}mm auto-trim threshold.`,
    current, next
  };
}


export function analyzeGap(gapVector, context, current, next, config) {
  const cfg = config.smartFixer || {};
  const negligible = cfg.negligibleGap ?? 1.0;
  const autoFillMax = cfg.autoFillMaxGap ?? 25.0;
  const reviewMax = cfg.reviewGapMax ?? 100.0;
  const silentSnap = cfg.silentSnapThreshold ?? 2.0;

  const gapMag = vec.mag(gapVector);

  // ─── R-GAP-01: Negligible gap ───
  if (gapMag < negligible) {
    if (gapMag > 0.1) {
      return {
        type: "SNAP", ruleId: "R-GAP-01", tier: 1,
        description: `SNAP [R-GAP-01]: Close ${gapMag.toFixed(2)}mm micro-gap by snapping endpoints.`,
        gapVector, current, next
      };
    }
    return null; // Perfect connection
  }

  // Decompose gap into axes
  const axes = decomposeGap(gapVector, cfg.offAxisThreshold ?? 0.5);
  const alongTravel = axes.find(a => a.axis === context.travelAxis);
  const lateral = axes.filter(a => a.axis !== context.travelAxis);
  const totalLateral = lateral.reduce((s, a) => s + Math.abs(a.delta), 0);
  const alongDelta = alongTravel ? alongTravel.delta : 0;
  const isOverlap = alongDelta * context.travelDirection < 0; // negative gap = overlap

  // ─── OVERLAP PATH ───
  if (isOverlap && axes.length === 1 && axes[0].axis === context.travelAxis) {
    const overlapAmt = Math.abs(alongDelta);
    return analyzeOverlap(overlapAmt, context, current, next, cfg);
  }

  // ─── GAP PATH ───

  // Single-axis gap along travel
  if (axes.length === 1 && axes[0].axis === context.travelAxis) {
    const gapAmt = Math.abs(alongDelta);
    const dir = directionLabel(context.travelAxis, context.travelDirection);

    if (gapAmt <= autoFillMax) {
      return {
        type: "INSERT", ruleId: "R-GAP-02", tier: 2,
        description: buildInsertDescription(gapAmt, dir, context, current),
        gapAmount: gapAmt, fillAxis: context.travelAxis, fillDir: context.travelDirection,
        current, next
      };
    }
    if (gapAmt <= reviewMax) {
      return {
        type: "REVIEW", ruleId: "R-GAP-03", tier: 3,
        description: `REVIEW [R-GAP-03]: ${gapAmt.toFixed(1)}mm gap along ${dir}. Exceeds ${autoFillMax}mm auto-fill threshold. Manual review.`,
        current, next
      };
    }
    return {
      type: "ERROR", ruleId: "R-GAP-03", tier: 4,
      description: `ERROR [R-GAP-03]: ${gapAmt.toFixed(1)}mm gap along ${dir}. Major gap — likely missing component(s).`,
      current, next
    };
  }

  // Single-axis gap on NON-travel axis (lateral)
  if (axes.length === 1 && axes[0].axis !== context.travelAxis) {
    const latAmt = Math.abs(axes[0].delta);
    if (latAmt < silentSnap) {
      return {
        type: "SNAP", ruleId: "R-GAP-04", tier: 2,
        description: `SNAP [R-GAP-04]: Lateral offset ${latAmt.toFixed(1)}mm on ${axes[0].axis}-axis (travel is ${context.travelAxis}). Snapping to align.`,
        current, next
      };
    }
    return {
      type: "ERROR", ruleId: "R-GAP-04", tier: 4,
      description: `ERROR [R-GAP-04]: Lateral offset ${latAmt.toFixed(1)}mm on ${axes[0].axis}-axis. Pipe has shifted sideways. Manual review.`,
      current, next
    };
  }

  // Multi-axis gap with negligible lateral
  if (axes.length >= 2 && totalLateral < silentSnap && Math.abs(alongDelta) <= autoFillMax) {
    const gapAmt = Math.abs(alongDelta);
    const dir = directionLabel(context.travelAxis, context.travelDirection);
    return {
      type: "INSERT", ruleId: "R-GAP-05", tier: 2,
      description: `INSERT [R-GAP-05]: Multi-axis gap (axial=${gapAmt.toFixed(1)}mm, lateral=${totalLateral.toFixed(1)}mm). Lateral snapped, axial filled with ${gapAmt.toFixed(1)}mm pipe ${dir}.`,
      gapAmount: gapAmt, fillAxis: context.travelAxis, fillDir: context.travelDirection,
      current, next
    };
  }

  // Multi-axis gap with significant components
  return {
    type: "ERROR", ruleId: "R-GAP-06", tier: 4,
    description: `ERROR [R-GAP-06]: Multi-axis gap (${formatGapAxes(axes)}). Cannot auto-fill. Rigorous manual review required.`,
    current, next
  };
}
